<template>
	<view>
		<div data-v-282af04b="" class="entrance-box"><!---->
			<div data-v-282af04b="" class="shuffle-box"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni0;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni1;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni2;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni3;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni4;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni5;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni6;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni7;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni8;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni9;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni10;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni11;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni12;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni13;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni14;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni15;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni16;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni17;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni18;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni19;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni20;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni21;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni22;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni23;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni24;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni25;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni26;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni27;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni28;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni29;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni30;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni31;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni32;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni33;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni34;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni35;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni36;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni37;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni38;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni39;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni40;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni41;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni42;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni43;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni44;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni45;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni46;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni47;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni48;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni49;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni50;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni51;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni52;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni53;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni54;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni55;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni56;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni57;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni58;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni59;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni60;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni61;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni62;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni63;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni64;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni65;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni66;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni67;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni68;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni69;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni70;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni71;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni72;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni73;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni74;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni75;"><img data-v-282af04b=""
					src="https://static.shengri.cn/uploads/QA_mp/slim/ic_arrow_Card@3x.png?imageslim" class="shuffle-image"
					style="animation-name: shuffleAni76;"></div>
		</div>
	</view>
</template>

<style>
	
	
	html,
	body {
	  background-color: #04073B;
	}
	
	.shadow {
	  width: 100vw;
	  height: 100vh;
	  position: fixed;
	  top: 0;
	  left: 0;
	  z-index: 5;
	  background: rgba(0, 0, 0, 0.45);
	}
	.mask-top,
	.mask-bottom {
	  z-index: 12;
	  width: 100%;
	  height: 0.96rem;
	  pointer-events: none;
	  transform: translateZ(0);
	}
	.mask-top {
	  position: absolute;
	  top: 0;
	  background: linear-gradient(to top, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9));
	}
	.mask-bottom {
	  position: absolute;
	  bottom: 0.02667rem;
	  background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9));
	}
	
	
	.shadow-fade-enter,
	.shadow-fade-leave-active {
	  opacity: 0;
	}
	.shadow-fade-enter-active,
	.shadow-fade-leave-active {
	  transition: all 0.35s ease;
	}
	.picker-move-enter,
	.picker-move-leave-active {
	  /* opacity: 0.5; */
	  transform: translate3d(0, 100%, 0);
	}
	.picker-move-enter-active,
	.picker-move-leave-active {
	  transition: all 0.35s ease;
	}
	
	.astrluck-copyright[data-v-aa3b07cc] {
	  width: 8.93333rem;
	  padding-top: 0.4rem;
	  padding-bottom: 0.4rem;
	  display: flex;
	  flex-direction: column;
	}
	.astrluck-copyright span[data-v-aa3b07cc] {
	  font-size: 0.32rem;
	  margin-bottom: 0.10667rem;
	  text-align: center;
	  line-height: 0.50667rem;
	}
	.astrluck-copyright span.driver[data-v-aa3b07cc] {
	  margin: 0 0.69333rem;
	}
	
	.tarot-init[data-v-282af04b] {
	  width: 100%;
	  height: 100%;
	  position: relative;
	}
	.tarot-init .entrance-box[data-v-282af04b] {
	  margin-top: 0.42667rem;
	  width: 10rem;
	  height: 10rem;
	}
	.tarot-init .entrance-box .init-box[data-v-282af04b] {
	  width: 10rem;
	  height: 10rem;
	  position: relative;
	}
	.tarot-init .entrance-box .init-box .entrance-image[data-v-282af04b] {
	  width: 3.04rem;
	  height: 5.06667rem;
	  position: absolute;
	  left: 3.46667rem;
	  top: 0;
	  transform-origin: 50% 100%;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-0[data-v-282af04b] {
	  transform: rotate(30deg) scale(0.8);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-1[data-v-282af04b] {
	  transform: rotate(15deg) scale(0.9);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-2[data-v-282af04b] {
	  transform: rotate(-30deg) scale(0.8);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-3[data-v-282af04b] {
	  transform: rotate(-15deg) scale(0.9);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-4[data-v-282af04b] {
	  transform: rotate(0) scale(1);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-0[data-v-282af04b] {
	  animation: entranceAni0-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-1[data-v-282af04b] {
	  animation: entranceAni1-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-2[data-v-282af04b] {
	  animation: entranceAni2-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-3[data-v-282af04b] {
	  animation: entranceAni3-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-4[data-v-282af04b] {
	  animation: entranceAni4-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .shuffle-box[data-v-282af04b] {
	  width: 10rem;
	  height: 10rem;
	  position: relative;
	}
	.tarot-init .entrance-box .shuffle-box .shuffle-image[data-v-282af04b] {
	  width: 3.04rem;
	  height: 5.06667rem;
	  position: absolute;
	  left: 3.46667rem;
	  top: 20%;
	  transform: rotate(0) scale(0.5);
	  transform-origin: 50% 100%;
	  animation-duration: 3.5s;
	  animation-timing-function: ease;
	  animation-fill-mode: forwards;
	}
	.tarot-init .init-action[data-v-282af04b] {
	  width: 10rem;
	  height: 6.4rem;
	  position: absolute;
	  left: 0;
	  bottom: 0;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.tarot-init .init-action .init-desc[data-v-282af04b] {
	  width: 7.62667rem;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: space-between;
	}
	.tarot-init .init-action .init-desc .init-icon[data-v-282af04b] {
	  width: 0.50667rem;
	}
	.tarot-init .init-action .init-desc .desc-content[data-v-282af04b] {
	  width: 5.86667rem;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.tarot-init .init-action .init-desc .desc-content p[data-v-282af04b] {
	  font-size: 0.37333rem;
	  color: #fff;
	  text-align: center;
	  line-height: 0.48rem;
	  font-weight: 300;
	}
	.tarot-init .init-action .init-desc .desc-content p.start[data-v-282af04b] {
	  margin-top: 0.26667rem;
	}
	.tarot-init .init-action .shuffle-wrapper[data-v-282af04b] {
	  width: 3.46667rem;
	  height: 3.46667rem;
	  display: flex;
	  flex-direction: row;
	  justify-content: center;
	  align-items: center;
	  background-image: url(https://static.shengri.cn/uploads/QA_mp/slim/Circle.gif?imageslim);
	  background-repeat: no-repeat;
	  background-size: 100%;
	  margin-top: 0.53333rem;
	}
	.tarot-init .init-action .shuffle-wrapper .shuffle-btn[data-v-282af04b] {
	  width: 2.34667rem;
	  height: 2.34667rem;
	  line-height: 2.34667rem;
	  text-align: center;
	  font-size: 0.42667rem;
	  color: #313a5a;
	  background-image: url(https://static.shengri.cn/uploads/QA_mp/ic_tarrow_Btn_read.png?imageslim);
	  background-repeat: no-repeat;
	  background-size: 100%;
	}
	.tarot-init .shuffle-ing[data-v-282af04b] {
	  font-size: 0.37333rem;
	  color: #fff;
	  text-align: center;
	  font-weight: 300;
	}
	@keyframes entranceAni0-282af04b {
	0% {
	    top: 0;
	    transform: rotate(30deg) scale(0.8);
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	@keyframes entranceAni1-282af04b {
	0% {
	    top: 0;
	    transform: rotate(15deg) scale(0.9);
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	@keyframes entranceAni2-282af04b {
	0% {
	    top: 0;
	    transform: rotate(-30deg) scale(0.8);
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	@keyframes entranceAni3-282af04b {
	0% {
	    top: 0;
	    transform: rotate(-15deg) scale(0.9);
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	@keyframes entranceAni4-282af04b {
	0% {
	    top: 0;
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	
	.contact-wrapper[data-v-33344658] {
	  width: 0.96rem;
	  padding: 0.21333rem 0;
	  position: fixed;
	  top: 5.33333rem;
	  right: 0;
	  z-index: 3;
	  background: rgba(0, 0, 0, 0.65);
	  border-radius: 0.16rem 0 0 0.16rem;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  justify-content: center;
	}
	.contact-wrapper .contact-driver[data-v-33344658] {
	  width: 0.53333rem;
	  height: 0.05333rem;
	  background: rgba(255, 255, 255, 0.5);
	  border-radius: 0.02667rem;
	  margin: 0.26667rem 0;
	}
	.contact-wrapper .contact-item[data-v-33344658] {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.contact-wrapper .contact-item img[data-v-33344658] {
	  width: 0.53333rem;
	  height: 0.53333rem;
	  margin-bottom: 0.10667rem;
	}
	.contact-wrapper .contact-item span[data-v-33344658] {
	  font-size: 0.32rem;
	  color: rgba(255, 255, 255, 0.8);
	  line-height: 0.37333rem;
	}
	
	.tarot-play[data-v-60e6171d] {
	  width: 100%;
	  height: var(--vh);
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  background-image: url(https://static.shengri.cn/uploads/tarotSignIn/guangban.png?imageslim);
	  background-repeat: no-repeat;
	  background-size: 100%;
	}
	.tarot-play .header-img[data-v-60e6171d] {
	  width: 3.68rem;
	  height: 1.49333rem;
	  margin: 1.06667rem auto 0;
	  background-image: url(https://static.shengri.cn/uploads/QA_mp/ic_toubuwenzi@3x.png?imageslim);
	  background-repeat: no-repeat;
	  background-size: 3.68rem 1.49333rem;
	}
	.tarot-play .step-content[data-v-60e6171d] {
	  width: 100%;
	  height: calc(var(--vh) - 2.56rem);
	}
	.user-ask[data-v-60e6171d] {
	  width: 2.02667rem;
	  height: 0.69333rem;
	  position: fixed;
	  right: 0;
	  bottom: 1.6rem;
	  z-index: 10;
	}
	
	.ask-dialog[data-v-d2646a3c] {
	  width: 100vw;
	  height: var(--vh);
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: center;
	  position: fixed;
	  z-index: 10;
	  left: 50%;
	  top: 0;
	  transform: translateX(-50%);
	}
	.ask-dialog .dialog-mask[data-v-d2646a3c] {
	  position: absolute;
	  width: 100%;
	  height: 100%;
	  background: rgba(0, 0, 0, 0.45);
	}
	.ask-dialog .dialog-wrapper[data-v-d2646a3c] {
	  width: 8.13333rem;
	  padding: 0.8rem 0.8rem;
	  box-sizing: border-box;
	  background: #ffffff;
	  border-radius: 0.26667rem;
	  position: relative;
	}
	.ask-dialog .dialog-wrapper .dialog-close[data-v-d2646a3c] {
	  position: absolute;
	  right: 0.48rem;
	  top: 0.48rem;
	  font-size: 0.48rem;
	}
	.ask-dialog .dialog-wrapper .dialog-title[data-v-d2646a3c] {
	  font-size: 0.48rem;
	  font-family: PingFangSC-Medium, PingFang SC;
	  color: #333333;
	  text-align: center;
	}
	.ask-dialog .dialog-wrapper .dialog-content[data-v-d2646a3c] {
	  width: 100%;
	  margin: 0.42667rem 0 0.64rem;
	  font-size: 0.37333rem;
	  font-family: PingFangSC-Regular, PingFang SC;
	  font-weight: 400;
	  color: #333333;
	  line-height: 0.64rem;
	  text-align: center;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper[data-v-d2646a3c] {
	  width: 100%;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper.alert[data-v-d2646a3c] {
	  justify-content: center;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper.confirm[data-v-d2646a3c] {
	  justify-content: space-between;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper .btn[data-v-d2646a3c] {
	  width: 3.2rem;
	  height: 1.06667rem;
	  border-radius: 0.53333rem;
	  font-size: 0.42667rem;
	  font-family: PingFangSC-Regular, PingFang SC;
	  font-weight: 400;
	  text-align: center;
	  line-height: 1.06667rem;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper .btn.cancel[data-v-d2646a3c] {
	  background: #dadada;
	  color: #ffffff;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper .btn.comfirm[data-v-d2646a3c] {
	  background: #ffdd17;
	  color: #2b2144;
	}
	.dialog-zoom-enter-active[data-v-d2646a3c] {
	  animation: dialog-zoom-d2646a3c 0.4s;
	}
	@keyframes dialog-zoom-d2646a3c {
	0% {
	    transform: scale(0);
	}
	50% {
	    transform: scale(1.1);
	}
	100% {
	    transform: scale(1);
	}
	}
	
	.astrolabe-login .login-wrapper[data-v-91f21d1e] {
	  width: 8.93333rem;
	  height: 14.18667rem;
	  box-sizing: border-box;
	  padding: 0 0.66667rem;
	  background: #ffffff;
	  position: fixed;
	  top: 50%;
	  left: 50%;
	  transform: translate(-50%, -50%);
	  z-index: 11;
	  border-radius: 0.26667rem;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.astrolabe-login .login-wrapper .login-close[data-v-91f21d1e] {
	  right: 0.53333rem;
	  top: 0.53333rem;
	  position: absolute;
	  font-size: 0.48rem;
	  font-weight: bold;
	}
	.astrolabe-login .login-wrapper .loading-ico[data-v-91f21d1e] {
	  width: 3.04rem;
	  display: block;
	  margin-top: 1.33333rem;
	  animation: turn-91f21d1e 10s linear infinite;
	}
	.astrolabe-login .login-wrapper .login-tip[data-v-91f21d1e] {
	  width: 100%;
	  font-family: PingFangSC-Light;
	  font-size: 0.37333rem;
	  color: #999999;
	  letter-spacing: 0;
	  text-align: center;
	  margin-top: 0.74667rem;
	}
	.astrolabe-login .login-wrapper .sign-driver[data-v-91f21d1e] {
	  width: 100%;
	  font-family: PingFangSC-Light;
	  font-size: 0.32rem;
	  color: #999999;
	  letter-spacing: 0;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  margin-top: 0.98667rem;
	}
	.astrolabe-login .login-wrapper .sign-driver span[data-v-91f21d1e] {
	  margin: 0 0.26667rem;
	}
	.astrolabe-login .login-wrapper .sign-driver .driver[data-v-91f21d1e] {
	  flex: 1;
	  height: 0;
	  border-bottom: 0.02667rem solid #dcdde1;
	}
	.astrolabe-login .login-wrapper .login-form[data-v-91f21d1e] {
	  width: 100%;
	  margin-top: 0.26667rem;
	}
	.astrolabe-login .login-wrapper .login-form .form-item[data-v-91f21d1e] {
	  width: 100%;
	  height: 1.33333rem;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  border-bottom: 0.02667rem solid rgba(243, 243, 243, 0.7);
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-label[data-v-91f21d1e] {
	  width: 1.86667rem;
	  text-align: left;
	  height: 1.33333rem;
	  line-height: 1.33333rem;
	  font-family: PingFangSC-Regular;
	  font-size: 0.42667rem;
	  color: #333333;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content[data-v-91f21d1e] {
	  flex: 1;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-middle[data-v-91f21d1e] {
	  flex: 1;
	  height: 100%;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-middle .item-input[data-v-91f21d1e] {
	  width: 100%;
	  font-family: PingFangSC-Regular;
	  font-size: 0.42667rem;
	  color: #333333;
	  text-overflow: -o-ellipsis-lastline;
	  overflow: hidden;
	  text-overflow: ellipsis;
	  display: -webkit-box;
	  -webkit-line-clamp: 1;
	  line-clamp: 1;
	  -webkit-box-orient: vertical;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-middle .item-input[data-v-91f21d1e]::-webkit-input-placeholder {
	  font-family: PingFangSC-Light;
	  font-size: 0.42667rem;
	  color: #999999;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right[data-v-91f21d1e] {
	  display: flex;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right .sms-btn[data-v-91f21d1e] {
	  width: 1.33333rem;
	  height: 0.53333rem;
	  text-align: center;
	  line-height: 0.53333rem;
	  border-radius: 0.4rem;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: center;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right .sms-btn span[data-v-91f21d1e] {
	  font-family: PingFangSC-Regular;
	  font-size: 0.32rem;
	  color: #ffffff;
	  line-height: 0;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right .unlock[data-v-91f21d1e] {
	  background: #ff3939;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right .lock[data-v-91f21d1e] {
	  background: #dcdde1;
	}
	.astrolabe-login .login-wrapper .login-agreement[data-v-91f21d1e] {
	  width: 100%;
	  margin-top: 0.4rem;
	  display: flex;
	  flex-direction: row;
	}
	.astrolabe-login .login-wrapper .login-agreement .agreement[data-v-91f21d1e] {
	  font-family: PingFangSC-Light;
	  font-size: 0.34667rem;
	  color: #999999;
	  letter-spacing: 0;
	  margin-left: 0.10667rem;
	  line-height: 0.48rem;
	}
	.astrolabe-login .login-wrapper .login-agreement .agreement a[data-v-91f21d1e] {
	  font-family: PingFangSC-Light;
	  font-size: 0.34667rem;
	  color: #3478f6;
	  text-decoration: underline;
	}
	.astrolabe-login .login-wrapper .do-login[data-v-91f21d1e] {
	  margin-top: 0.8rem;
	}
	@keyframes turn-91f21d1e {
	0% {
	    -webkit-transform: rotate(0deg);
	}
	25% {
	    -webkit-transform: rotate(90deg);
	}
	50% {
	    -webkit-transform: rotate(180deg);
	}
	75% {
	    -webkit-transform: rotate(270deg);
	}
	100% {
	    -webkit-transform: rotate(360deg);
	}
	}
	
	.wx-qrcode-dialog .dialog-mask[data-v-308d50ee] {
	  width: 100vw;
	  height: var(--vh);
	  display: flex;
	  position: fixed;
	  z-index: 5;
	  left: 0;
	  top: 0;
	  background: rgba(0, 0, 0, 0.45);
	}
	.wx-qrcode-dialog .wx-qrcode[data-v-308d50ee] {
	  position: fixed;
	  z-index: 6;
	  left: 50%;
	  top: 50%;
	  transform: translate(-50%, -50%);
	  border-radius: 0.26667rem;
	  width: 8.13333rem;
	  padding: 0.8rem 0.8rem;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  box-sizing: border-box;
	  background-color: #ffffff;
	}
	.wx-qrcode-dialog .wx-qrcode .dialog-close[data-v-308d50ee] {
	  position: absolute;
	  right: 0.48rem;
	  top: 0.48rem;
	  font-size: 0.48rem;
	}
	.wx-qrcode-dialog .wx-qrcode .wx-qrcode-title[data-v-308d50ee] {
	  width: 100%;
	  font-size: 0.48rem;
	  color: #333333;
	  letter-spacing: 0;
	  text-align: center;
	}
	.wx-qrcode-dialog .wx-qrcode .qrcode-wrapper[data-v-308d50ee] {
	  width: 4.26667rem;
	  height: 4.26667rem;
	  margin-top: 0.4rem;
	  background: #ffffff;
	  border-radius: 0.10667rem;
	  margin-bottom: 0.4rem;
	  overflow: hidden;
	}
	.wx-qrcode-dialog .wx-qrcode .pay-tip[data-v-308d50ee] {
	  font-size: 0.32rem;
	  color: #333333;
	  font-weight: 300;
	  position: relative;
	}
	.wx-qrcode-dialog .wx-qrcode .pay-tip[data-v-308d50ee]::before {
	  content: "*";
	  font-weight: 700;
	  position: absolute;
	  left: -0.26667rem;
	  top: -0.05333rem;
	  color: #ff3939;
	}
	.dialog-zoom-enter-active[data-v-308d50ee] {
	  animation: dialog-zoom-308d50ee 0.4s;
	}
	@keyframes dialog-zoom-308d50ee {
	0% {
	    transform: scale(0);
	}
	50% {
	    transform: scale(1.1);
	}
	100% {
	    transform: scale(1);
	}
	}
	
	.mobile-scroll-wrapper[data-v-b9eb64fc] {
	  height: 100%;
	  position: relative;
	  overflow: hidden;
	}
	.mobile-scroll-wrapper .mobile-scroll-content[data-v-b9eb64fc] {
	  position: relative;
	  height: 100%;
	}
	.mobile-scroll-wrapper .mobile-scroll-content .scroll-wrapper[data-v-b9eb64fc] {
	  position: relative;
	  overflow: hidden;
	  height: 100%;
	}
	.mobile-scroll-wrapper .mobile-scroll-content .scroll-wrapper .scroll-content .pulldown-wrapper[data-v-b9eb64fc] {
	  position: absolute;
	  width: 100%;
	  padding: 0.53333rem;
	  box-sizing: border-box;
	  transform: translateY(-100%) translateZ(0);
	  text-align: center;
	  color: #999;
	  font-size: 0.37333rem;
	}
	.mobile-scroll-wrapper .mobile-scroll-content .scroll-wrapper .scroll-content .pullup-wrapper[data-v-b9eb64fc] {
	  width: 100%;
	  padding: 0.53333rem;
	  box-sizing: border-box;
	  text-align: center;
	  color: #999;
	  font-size: 0.37333rem;
	}
	
	.main-page[data-v-cf852a76] {
	  position: absolute;
	  width: 10rem;
	  height: 100%;
	  margin: auto;
	}
	.main-page .page-container[data-v-cf852a76] {
	  width: 100%;
	  height: 100%;
	  display: flex;
	  flex-direction: column;
	}
	.main-page .page-container .float-wrapper[data-v-cf852a76] {
	  width: 1.17333rem;
	  height: 1.17333rem;
	  position: absolute;
	  top: 0;
	  left: 0;
	  z-index: 5;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: center;
	}
	.main-page .page-container .float-wrapper .float-back[data-v-cf852a76] {
	  padding: 0 0.4rem;
	  color: #ffffff;
	  font-size: 0.4rem;
	}
	.main-page .page-container .header[data-v-cf852a76] {
	  position: relative;
	  height: 1.17333rem;
	  line-height: 1.17333rem;
	  text-align: center;
	  background-color: transparent;
	  -webkit-backface-visibility: hidden;
	  backface-visibility: hidden;
	  z-index: 5;
	}
	.main-page .page-container .header h1[data-v-cf852a76] {
	  font-size: 0.42667rem;
	  color: #ffffff;
	}
	.main-page .page-container .header .mainic-back[data-v-cf852a76] {
	  position: absolute;
	  top: 0;
	  left: 0;
	  padding: 0 0.4rem;
	  color: #ffffff;
	  font-size: 0.4rem;
	}
	.main-page .page-container .content[data-v-cf852a76] {
	  width: 100%;
	  -webkit-overflow-scrolling: touch;
	  position: relative;
	}
	.main-page .page-container .content .marquee[data-v-cf852a76] {
	  position: absolute;
	  left: 0;
	  top: 0;
	  z-index: 2;
	  width: 100%;
	  height: 0.53333rem;
	  background: rgba(30, 12, 12, 0.6);
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	.main-page .page-container .content .footer[data-v-cf852a76] {
	  position: absolute;
	  left: 0;
	  bottom: -0.02667rem;
	  z-index: 2;
	  width: 100%;
	}
	.page[data-v-cf852a76] {
	  position: relative;
	}
	.page .copyright[data-v-cf852a76] {
	  width: 100%;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: center;
	  font-size: 0.32rem;
	  color: #dddddd;
	}
	

	
	html,
	body {
	  background-color: #04073B;
	}
	
	.shadow {
	  width: 100vw;
	  height: 100vh;
	  position: fixed;
	  top: 0;
	  left: 0;
	  z-index: 5;
	  background: rgba(0, 0, 0, 0.45);
	}
	.mask-top,
	.mask-bottom {
	  z-index: 12;
	  width: 100%;
	  height: 0.96rem;
	  pointer-events: none;
	  transform: translateZ(0);
	}
	.mask-top {
	  position: absolute;
	  top: 0;
	  background: linear-gradient(to top, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9));
	}
	.mask-bottom {
	  position: absolute;
	  bottom: 0.02667rem;
	  background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9));
	}
	
	
	.shadow-fade-enter,
	.shadow-fade-leave-active {
	  opacity: 0;
	}
	.shadow-fade-enter-active,
	.shadow-fade-leave-active {
	  transition: all 0.35s ease;
	}
	.picker-move-enter,
	.picker-move-leave-active {
	  /* opacity: 0.5; */
	  transform: translate3d(0, 100%, 0);
	}
	.picker-move-enter-active,
	.picker-move-leave-active {
	  transition: all 0.35s ease;
	}
	
	.astrluck-copyright[data-v-aa3b07cc] {
	  width: 8.93333rem;
	  padding-top: 0.4rem;
	  padding-bottom: 0.4rem;
	  display: flex;
	  flex-direction: column;
	}
	.astrluck-copyright span[data-v-aa3b07cc] {
	  font-size: 0.32rem;
	  margin-bottom: 0.10667rem;
	  text-align: center;
	  line-height: 0.50667rem;
	}
	.astrluck-copyright span.driver[data-v-aa3b07cc] {
	  margin: 0 0.69333rem;
	}
	
	.tarot-init[data-v-282af04b] {
	  width: 100%;
	  height: 100%;
	  position: relative;
	}
	.tarot-init .entrance-box[data-v-282af04b] {
	  margin-top: 0.42667rem;
	  width: 10rem;
	  height: 10rem;
	}
	.tarot-init .entrance-box .init-box[data-v-282af04b] {
	  width: 10rem;
	  height: 10rem;
	  position: relative;
	}
	.tarot-init .entrance-box .init-box .entrance-image[data-v-282af04b] {
	  width: 3.04rem;
	  height: 5.06667rem;
	  position: absolute;
	  left: 3.46667rem;
	  top: 0;
	  transform-origin: 50% 100%;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-0[data-v-282af04b] {
	  transform: rotate(30deg) scale(0.8);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-1[data-v-282af04b] {
	  transform: rotate(15deg) scale(0.9);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-2[data-v-282af04b] {
	  transform: rotate(-30deg) scale(0.8);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-3[data-v-282af04b] {
	  transform: rotate(-15deg) scale(0.9);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-transform-4[data-v-282af04b] {
	  transform: rotate(0) scale(1);
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-0[data-v-282af04b] {
	  animation: entranceAni0-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-1[data-v-282af04b] {
	  animation: entranceAni1-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-2[data-v-282af04b] {
	  animation: entranceAni2-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-3[data-v-282af04b] {
	  animation: entranceAni3-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .init-box .entrance-image.entrance-image-animate-4[data-v-282af04b] {
	  animation: entranceAni4-282af04b 1.5s linear forwards;
	}
	.tarot-init .entrance-box .shuffle-box[data-v-282af04b] {
	  width: 10rem;
	  height: 10rem;
	  position: relative;
	}
	.tarot-init .entrance-box .shuffle-box .shuffle-image[data-v-282af04b] {
	  width: 3.04rem;
	  height: 5.06667rem;
	  position: absolute;
	  left: 3.46667rem;
	  top: 20%;
	  transform: rotate(0) scale(0.5);
	  transform-origin: 50% 100%;
	  animation-duration: 3.5s;
	  animation-timing-function: ease;
	  animation-fill-mode: forwards;
	}
	.tarot-init .init-action[data-v-282af04b] {
	  width: 10rem;
	  height: 6.4rem;
	  position: absolute;
	  left: 0;
	  bottom: 0;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.tarot-init .init-action .init-desc[data-v-282af04b] {
	  width: 7.62667rem;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: space-between;
	}
	.tarot-init .init-action .init-desc .init-icon[data-v-282af04b] {
	  width: 0.50667rem;
	}
	.tarot-init .init-action .init-desc .desc-content[data-v-282af04b] {
	  width: 5.86667rem;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.tarot-init .init-action .init-desc .desc-content p[data-v-282af04b] {
	  font-size: 0.37333rem;
	  color: #fff;
	  text-align: center;
	  line-height: 0.48rem;
	  font-weight: 300;
	}
	.tarot-init .init-action .init-desc .desc-content p.start[data-v-282af04b] {
	  margin-top: 0.26667rem;
	}
	.tarot-init .init-action .shuffle-wrapper[data-v-282af04b] {
	  width: 3.46667rem;
	  height: 3.46667rem;
	  display: flex;
	  flex-direction: row;
	  justify-content: center;
	  align-items: center;
	  background-image: url(https://static.shengri.cn/uploads/QA_mp/slim/Circle.gif?imageslim);
	  background-repeat: no-repeat;
	  background-size: 100%;
	  margin-top: 0.53333rem;
	}
	.tarot-init .init-action .shuffle-wrapper .shuffle-btn[data-v-282af04b] {
	  width: 2.34667rem;
	  height: 2.34667rem;
	  line-height: 2.34667rem;
	  text-align: center;
	  font-size: 0.42667rem;
	  color: #313a5a;
	  background-image: url(https://static.shengri.cn/uploads/QA_mp/ic_tarrow_Btn_read.png?imageslim);
	  background-repeat: no-repeat;
	  background-size: 100%;
	}
	.tarot-init .shuffle-ing[data-v-282af04b] {
	  font-size: 0.37333rem;
	  color: #fff;
	  text-align: center;
	  font-weight: 300;
	}
	@keyframes entranceAni0-282af04b {
	0% {
	    top: 0;
	    transform: rotate(30deg) scale(0.8);
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	@keyframes entranceAni1-282af04b {
	0% {
	    top: 0;
	    transform: rotate(15deg) scale(0.9);
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	@keyframes entranceAni2-282af04b {
	0% {
	    top: 0;
	    transform: rotate(-30deg) scale(0.8);
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	@keyframes entranceAni3-282af04b {
	0% {
	    top: 0;
	    transform: rotate(-15deg) scale(0.9);
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	@keyframes entranceAni4-282af04b {
	0% {
	    top: 0;
	}
	46% {
	    top: 0;
	    transform: rotate(0) scale(1);
	}
	100% {
	    top: 20%;
	    transform: rotate(0) scale(0.5);
	}
	}
	
	.contact-wrapper[data-v-33344658] {
	  width: 0.96rem;
	  padding: 0.21333rem 0;
	  position: fixed;
	  top: 5.33333rem;
	  right: 0;
	  z-index: 3;
	  background: rgba(0, 0, 0, 0.65);
	  border-radius: 0.16rem 0 0 0.16rem;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  justify-content: center;
	}
	.contact-wrapper .contact-driver[data-v-33344658] {
	  width: 0.53333rem;
	  height: 0.05333rem;
	  background: rgba(255, 255, 255, 0.5);
	  border-radius: 0.02667rem;
	  margin: 0.26667rem 0;
	}
	.contact-wrapper .contact-item[data-v-33344658] {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.contact-wrapper .contact-item img[data-v-33344658] {
	  width: 0.53333rem;
	  height: 0.53333rem;
	  margin-bottom: 0.10667rem;
	}
	.contact-wrapper .contact-item span[data-v-33344658] {
	  font-size: 0.32rem;
	  color: rgba(255, 255, 255, 0.8);
	  line-height: 0.37333rem;
	}
	
	.tarot-play[data-v-60e6171d] {
	  width: 100%;
	  height: var(--vh);
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  background-image: url(https://static.shengri.cn/uploads/tarotSignIn/guangban.png?imageslim);
	  background-repeat: no-repeat;
	  background-size: 100%;
	}
	.tarot-play .header-img[data-v-60e6171d] {
	  width: 3.68rem;
	  height: 1.49333rem;
	  margin: 1.06667rem auto 0;
	  background-image: url(https://static.shengri.cn/uploads/QA_mp/ic_toubuwenzi@3x.png?imageslim);
	  background-repeat: no-repeat;
	  background-size: 3.68rem 1.49333rem;
	}
	.tarot-play .step-content[data-v-60e6171d] {
	  width: 100%;
	  height: calc(var(--vh) - 2.56rem);
	}
	.user-ask[data-v-60e6171d] {
	  width: 2.02667rem;
	  height: 0.69333rem;
	  position: fixed;
	  right: 0;
	  bottom: 1.6rem;
	  z-index: 10;
	}
	
	.ask-dialog[data-v-d2646a3c] {
	  width: 100vw;
	  height: var(--vh);
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: center;
	  position: fixed;
	  z-index: 10;
	  left: 50%;
	  top: 0;
	  transform: translateX(-50%);
	}
	.ask-dialog .dialog-mask[data-v-d2646a3c] {
	  position: absolute;
	  width: 100%;
	  height: 100%;
	  background: rgba(0, 0, 0, 0.45);
	}
	.ask-dialog .dialog-wrapper[data-v-d2646a3c] {
	  width: 8.13333rem;
	  padding: 0.8rem 0.8rem;
	  box-sizing: border-box;
	  background: #ffffff;
	  border-radius: 0.26667rem;
	  position: relative;
	}
	.ask-dialog .dialog-wrapper .dialog-close[data-v-d2646a3c] {
	  position: absolute;
	  right: 0.48rem;
	  top: 0.48rem;
	  font-size: 0.48rem;
	}
	.ask-dialog .dialog-wrapper .dialog-title[data-v-d2646a3c] {
	  font-size: 0.48rem;
	  font-family: PingFangSC-Medium, PingFang SC;
	  color: #333333;
	  text-align: center;
	}
	.ask-dialog .dialog-wrapper .dialog-content[data-v-d2646a3c] {
	  width: 100%;
	  margin: 0.42667rem 0 0.64rem;
	  font-size: 0.37333rem;
	  font-family: PingFangSC-Regular, PingFang SC;
	  font-weight: 400;
	  color: #333333;
	  line-height: 0.64rem;
	  text-align: center;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper[data-v-d2646a3c] {
	  width: 100%;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper.alert[data-v-d2646a3c] {
	  justify-content: center;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper.confirm[data-v-d2646a3c] {
	  justify-content: space-between;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper .btn[data-v-d2646a3c] {
	  width: 3.2rem;
	  height: 1.06667rem;
	  border-radius: 0.53333rem;
	  font-size: 0.42667rem;
	  font-family: PingFangSC-Regular, PingFang SC;
	  font-weight: 400;
	  text-align: center;
	  line-height: 1.06667rem;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper .btn.cancel[data-v-d2646a3c] {
	  background: #dadada;
	  color: #ffffff;
	}
	.ask-dialog .dialog-wrapper .btn-wrapper .btn.comfirm[data-v-d2646a3c] {
	  background: #ffdd17;
	  color: #2b2144;
	}
	.dialog-zoom-enter-active[data-v-d2646a3c] {
	  animation: dialog-zoom-d2646a3c 0.4s;
	}
	@keyframes dialog-zoom-d2646a3c {
	0% {
	    transform: scale(0);
	}
	50% {
	    transform: scale(1.1);
	}
	100% {
	    transform: scale(1);
	}
	}
	
	.astrolabe-login .login-wrapper[data-v-91f21d1e] {
	  width: 8.93333rem;
	  height: 14.18667rem;
	  box-sizing: border-box;
	  padding: 0 0.66667rem;
	  background: #ffffff;
	  position: fixed;
	  top: 50%;
	  left: 50%;
	  transform: translate(-50%, -50%);
	  z-index: 11;
	  border-radius: 0.26667rem;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.astrolabe-login .login-wrapper .login-close[data-v-91f21d1e] {
	  right: 0.53333rem;
	  top: 0.53333rem;
	  position: absolute;
	  font-size: 0.48rem;
	  font-weight: bold;
	}
	.astrolabe-login .login-wrapper .loading-ico[data-v-91f21d1e] {
	  width: 3.04rem;
	  display: block;
	  margin-top: 1.33333rem;
	  animation: turn-91f21d1e 10s linear infinite;
	}
	.astrolabe-login .login-wrapper .login-tip[data-v-91f21d1e] {
	  width: 100%;
	  font-family: PingFangSC-Light;
	  font-size: 0.37333rem;
	  color: #999999;
	  letter-spacing: 0;
	  text-align: center;
	  margin-top: 0.74667rem;
	}
	.astrolabe-login .login-wrapper .sign-driver[data-v-91f21d1e] {
	  width: 100%;
	  font-family: PingFangSC-Light;
	  font-size: 0.32rem;
	  color: #999999;
	  letter-spacing: 0;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  margin-top: 0.98667rem;
	}
	.astrolabe-login .login-wrapper .sign-driver span[data-v-91f21d1e] {
	  margin: 0 0.26667rem;
	}
	.astrolabe-login .login-wrapper .sign-driver .driver[data-v-91f21d1e] {
	  flex: 1;
	  height: 0;
	  border-bottom: 0.02667rem solid #dcdde1;
	}
	.astrolabe-login .login-wrapper .login-form[data-v-91f21d1e] {
	  width: 100%;
	  margin-top: 0.26667rem;
	}
	.astrolabe-login .login-wrapper .login-form .form-item[data-v-91f21d1e] {
	  width: 100%;
	  height: 1.33333rem;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  border-bottom: 0.02667rem solid rgba(243, 243, 243, 0.7);
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-label[data-v-91f21d1e] {
	  width: 1.86667rem;
	  text-align: left;
	  height: 1.33333rem;
	  line-height: 1.33333rem;
	  font-family: PingFangSC-Regular;
	  font-size: 0.42667rem;
	  color: #333333;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content[data-v-91f21d1e] {
	  flex: 1;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-middle[data-v-91f21d1e] {
	  flex: 1;
	  height: 100%;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-middle .item-input[data-v-91f21d1e] {
	  width: 100%;
	  font-family: PingFangSC-Regular;
	  font-size: 0.42667rem;
	  color: #333333;
	  text-overflow: -o-ellipsis-lastline;
	  overflow: hidden;
	  text-overflow: ellipsis;
	  display: -webkit-box;
	  -webkit-line-clamp: 1;
	  line-clamp: 1;
	  -webkit-box-orient: vertical;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-middle .item-input[data-v-91f21d1e]::-webkit-input-placeholder {
	  font-family: PingFangSC-Light;
	  font-size: 0.42667rem;
	  color: #999999;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right[data-v-91f21d1e] {
	  display: flex;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right .sms-btn[data-v-91f21d1e] {
	  width: 1.33333rem;
	  height: 0.53333rem;
	  text-align: center;
	  line-height: 0.53333rem;
	  border-radius: 0.4rem;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: center;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right .sms-btn span[data-v-91f21d1e] {
	  font-family: PingFangSC-Regular;
	  font-size: 0.32rem;
	  color: #ffffff;
	  line-height: 0;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right .unlock[data-v-91f21d1e] {
	  background: #ff3939;
	}
	.astrolabe-login .login-wrapper .login-form .form-item .item-content .item-right .lock[data-v-91f21d1e] {
	  background: #dcdde1;
	}
	.astrolabe-login .login-wrapper .login-agreement[data-v-91f21d1e] {
	  width: 100%;
	  margin-top: 0.4rem;
	  display: flex;
	  flex-direction: row;
	}
	.astrolabe-login .login-wrapper .login-agreement .agreement[data-v-91f21d1e] {
	  font-family: PingFangSC-Light;
	  font-size: 0.34667rem;
	  color: #999999;
	  letter-spacing: 0;
	  margin-left: 0.10667rem;
	  line-height: 0.48rem;
	}
	.astrolabe-login .login-wrapper .login-agreement .agreement a[data-v-91f21d1e] {
	  font-family: PingFangSC-Light;
	  font-size: 0.34667rem;
	  color: #3478f6;
	  text-decoration: underline;
	}
	.astrolabe-login .login-wrapper .do-login[data-v-91f21d1e] {
	  margin-top: 0.8rem;
	}
	@keyframes turn-91f21d1e {
	0% {
	    -webkit-transform: rotate(0deg);
	}
	25% {
	    -webkit-transform: rotate(90deg);
	}
	50% {
	    -webkit-transform: rotate(180deg);
	}
	75% {
	    -webkit-transform: rotate(270deg);
	}
	100% {
	    -webkit-transform: rotate(360deg);
	}
	}
	
	.wx-qrcode-dialog .dialog-mask[data-v-308d50ee] {
	  width: 100vw;
	  height: var(--vh);
	  display: flex;
	  position: fixed;
	  z-index: 5;
	  left: 0;
	  top: 0;
	  background: rgba(0, 0, 0, 0.45);
	}
	.wx-qrcode-dialog .wx-qrcode[data-v-308d50ee] {
	  position: fixed;
	  z-index: 6;
	  left: 50%;
	  top: 50%;
	  transform: translate(-50%, -50%);
	  border-radius: 0.26667rem;
	  width: 8.13333rem;
	  padding: 0.8rem 0.8rem;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  box-sizing: border-box;
	  background-color: #ffffff;
	}
	.wx-qrcode-dialog .wx-qrcode .dialog-close[data-v-308d50ee] {
	  position: absolute;
	  right: 0.48rem;
	  top: 0.48rem;
	  font-size: 0.48rem;
	}
	.wx-qrcode-dialog .wx-qrcode .wx-qrcode-title[data-v-308d50ee] {
	  width: 100%;
	  font-size: 0.48rem;
	  color: #333333;
	  letter-spacing: 0;
	  text-align: center;
	}
	.wx-qrcode-dialog .wx-qrcode .qrcode-wrapper[data-v-308d50ee] {
	  width: 4.26667rem;
	  height: 4.26667rem;
	  margin-top: 0.4rem;
	  background: #ffffff;
	  border-radius: 0.10667rem;
	  margin-bottom: 0.4rem;
	  overflow: hidden;
	}
	.wx-qrcode-dialog .wx-qrcode .pay-tip[data-v-308d50ee] {
	  font-size: 0.32rem;
	  color: #333333;
	  font-weight: 300;
	  position: relative;
	}
	.wx-qrcode-dialog .wx-qrcode .pay-tip[data-v-308d50ee]::before {
	  content: "*";
	  font-weight: 700;
	  position: absolute;
	  left: -0.26667rem;
	  top: -0.05333rem;
	  color: #ff3939;
	}
	.dialog-zoom-enter-active[data-v-308d50ee] {
	  animation: dialog-zoom-308d50ee 0.4s;
	}
	@keyframes dialog-zoom-308d50ee {
	0% {
	    transform: scale(0);
	}
	50% {
	    transform: scale(1.1);
	}
	100% {
	    transform: scale(1);
	}
	}
	
	.mobile-scroll-wrapper[data-v-b9eb64fc] {
	  height: 100%;
	  position: relative;
	  overflow: hidden;
	}
	.mobile-scroll-wrapper .mobile-scroll-content[data-v-b9eb64fc] {
	  position: relative;
	  height: 100%;
	}
	.mobile-scroll-wrapper .mobile-scroll-content .scroll-wrapper[data-v-b9eb64fc] {
	  position: relative;
	  overflow: hidden;
	  height: 100%;
	}
	.mobile-scroll-wrapper .mobile-scroll-content .scroll-wrapper .scroll-content .pulldown-wrapper[data-v-b9eb64fc] {
	  position: absolute;
	  width: 100%;
	  padding: 0.53333rem;
	  box-sizing: border-box;
	  transform: translateY(-100%) translateZ(0);
	  text-align: center;
	  color: #999;
	  font-size: 0.37333rem;
	}
	.mobile-scroll-wrapper .mobile-scroll-content .scroll-wrapper .scroll-content .pullup-wrapper[data-v-b9eb64fc] {
	  width: 100%;
	  padding: 0.53333rem;
	  box-sizing: border-box;
	  text-align: center;
	  color: #999;
	  font-size: 0.37333rem;
	}
	
	.main-page[data-v-cf852a76] {
	  position: absolute;
	  width: 10rem;
	  height: 100%;
	  margin: auto;
	}
	.main-page .page-container[data-v-cf852a76] {
	  width: 100%;
	  height: 100%;
	  display: flex;
	  flex-direction: column;
	}
	.main-page .page-container .float-wrapper[data-v-cf852a76] {
	  width: 1.17333rem;
	  height: 1.17333rem;
	  position: absolute;
	  top: 0;
	  left: 0;
	  z-index: 5;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: center;
	}
	.main-page .page-container .float-wrapper .float-back[data-v-cf852a76] {
	  padding: 0 0.4rem;
	  color: #ffffff;
	  font-size: 0.4rem;
	}
	.main-page .page-container .header[data-v-cf852a76] {
	  position: relative;
	  height: 1.17333rem;
	  line-height: 1.17333rem;
	  text-align: center;
	  background-color: transparent;
	  -webkit-backface-visibility: hidden;
	  backface-visibility: hidden;
	  z-index: 5;
	}
	.main-page .page-container .header h1[data-v-cf852a76] {
	  font-size: 0.42667rem;
	  color: #ffffff;
	}
	.main-page .page-container .header .mainic-back[data-v-cf852a76] {
	  position: absolute;
	  top: 0;
	  left: 0;
	  padding: 0 0.4rem;
	  color: #ffffff;
	  font-size: 0.4rem;
	}
	.main-page .page-container .content[data-v-cf852a76] {
	  width: 100%;
	  -webkit-overflow-scrolling: touch;
	  position: relative;
	}
	.main-page .page-container .content .marquee[data-v-cf852a76] {
	  position: absolute;
	  left: 0;
	  top: 0;
	  z-index: 2;
	  width: 100%;
	  height: 0.53333rem;
	  background: rgba(30, 12, 12, 0.6);
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	.main-page .page-container .content .footer[data-v-cf852a76] {
	  position: absolute;
	  left: 0;
	  bottom: -0.02667rem;
	  z-index: 2;
	  width: 100%;
	}
	.page[data-v-cf852a76] {
	  position: relative;
	}
	.page .copyright[data-v-cf852a76] {
	  width: 100%;
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	  justify-content: center;
	  font-size: 0.32rem;
	  color: #dddddd;
	}
	

</style>