export const kapaiData = [
	{
		name: 'The Magician',
		path: '/static/kapai/m_magician.png'
	},
	{
		name: 'The Empress',
		path: '/static/kapai/m_empress.png'
	},
	{
		name: 'The Lovers',
		path: '/static/kapai/m_lovers.png'
	},
	{
		name: 'Strength',
		path: '/static/kapai/m_strength.png'
	},
	{
		name: 'The Hermit',
		path: '/static/kapai/m_hermit.png'
	},
	{
		name: 'Death',
		path: '/static/kapai/m_death.png'
	},
	{
		name: 'The Devil',
		path: '/static/kapai/m_devil.png'
	},
	{
		name: 'The Star',
		path: '/static/kapai/m_star.png'
	},
	{
		name: 'Scepter 4',
		path: '/static/kapai/quanzhang4.png'
	},
	{
		name: 'Scepter 6',
		path: '/static/kapai/quanzhang6.png'
	},
	{
		name: 'Scepter Knight',
		path: '/static/kapai/quanzhangknight.png'
	},
	{
		name: 'Grail 2',
		path: '/static/kapai/shengbei2.png'
	},
	{
		name: 'Grail 3',
		path: '/static/kapai/shengbei3.png'
	},
	{
		name: 'Grail 5',
		path: '/static/kapai/shengbei5.png'
	},
	{
		name: 'Grail 6',
		path: '/static/kapai/shengbei6.png'
	},
	{
		name: 'Grail Knight',
		path: '/static/kapai/shengbeiknight.png'
	},
	{
		name: 'Swords Ace',
		path: '/static/kapai/baojian1.png'
	},
	{
		name: 'Swords 3',
		path: '/static/kapai/baojian3.png'
	},
	{
		name: 'Pentacles 3',
		path: '/static/kapai/xingbi3.png'
	},
	{
		name: 'Pentacles 10',
		path: '/static/kapai/xingbi10.png'
	},
]